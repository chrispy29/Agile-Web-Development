<!--Christopher Prickett 30053736. 18/04/2023-->
<?php
// connects to database giving credentials
    const DB_HOST = 'localhost';
    const DB_NAME = 'questions';
    const DB_USER = 'adminer';
    const DB_PASSWORD = 'P@ssw0rd';
//using PDO for security	
$pdo = new PDO("mysql:host=" . DB_HOST . "; dbname=" . DB_NAME, DB_USER, DB_PASSWORD);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
  ?>