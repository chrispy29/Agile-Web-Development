<!--Christopher Prickett - 30053736. 13/03/23. AT3-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Questions</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
  <body>
  <!--Connection php used by each question-->
  <?php include_once('connection.php');?>
    <!--Navigation Bar-->
<?php include_once('NavBar.php');?><br>
<!--Contents of Contacts page-->
<main class="container">
  <div class="bg-light p-5 rounded"><br>
    <h1>Questions</h1> 
<p class="lead">Match the correct description and answer to eaach question.</p>	
  </div>
<br>
<div class="m-4">
<!--Accordion button for Question 1-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseOne">Question 1</button>									
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 1";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
    <!--Accordion button for Question 2-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">Question 2</button>									
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 2";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
    <!--Accordion button for Question 3-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree">Question 3</button>									
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 3";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
    <!--Accordion button for Question 4-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingFour">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour">Question 4</button>									
            </h2>
            <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 4";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
    <!--Accordion button for Question 5-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingFive">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFive">Question 5</button>									
            </h2>
            <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 5";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
    <!--Accordion button for Question 6-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingSix">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseSix">Question 6</button>									
            </h2>
            <div id="collapseSix" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 6";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
    <!--Accordion button for Question 7-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingSeven">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseSeven">Question 7</button>									
            </h2>
            <div id="collapseSeven" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 7";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
    <!--Accordion button for Question 8-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingEight">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseEight">Question 8</button>									
            </h2>
            <div id="collapseEight" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 8";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
    <!--Accordion button for Question 9-->
    <div class="accordion" id="myAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingNine">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseNine">Question 9</button>									
            </h2>
            <div id="collapseNine" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                <div class="card-body">
<?php
    //Query to select everything from the table where id matches            
    $query = "SELECT * FROM questions WHERE id = 9";

//submits and calls query from database
$sql = $query;
$stmt = $pdo->prepare($sql);
$stmt->execute();
  ?>
  
  <table cellpadding="10" align="center" style="border-collapse: collapse; border: 1px solid black; border-radius: 10px;">
    <tr style="border: 1px solid black;">
        <th style="border: 1px solid black;  border-radius: 10px;">ID</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Question</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Description</th>
        <th style="border: 1px solid black;  border-radius: 10px;">Answer</th>
    </tr>
			
  <!--php used to echo table and display database contents inside -->			
  <?php
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        echo "<tr style='border: 1px solid black;'>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['id'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['question'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['description'] . "</td>";
            echo "<td style='border: 1px solid black;  border-radius: 10px;'>" . $row['answer'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
?>
		</div>
	</div>
  </div>
  </div>
  </div>
            
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
     
  </body>
</html>