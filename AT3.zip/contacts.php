<!--Christopher Prickett - 30053736. 7/02/23-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Contacts</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
  <body>
    <!--Navigation Bar-->
<?php include_once('NavBar.php');?><br>
<!--Contents of Contacts page-->
<main class="container">
  <div class="bg-light p-5 rounded"><br>
    <h1>Contacts</h1>
    <p class="lead">CITEMS<a class="nav-link" href="https://www.citems.com.au/">https://www.citems.com.au/</a><br>
	SMTAFE<a class="nav-link" href="https://www.southmetrotafe.wa.edu.au/">https://www.southmetrotafe.wa.edu.au/</p>
  </div>
</main>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>
