<!--Christopher Prickett - 30053736. 7/02/23-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
  <body>
    <!--Navigation Bar-->
<?php include_once('NavBar.php')?><br>
<!--Contents of index page-->
<main class="container">
  <div class="bg-light p-5 rounded"><br>
    <h1>Welcome to Assessment Three</h1>
    <p class="lead">Assessment 3 - Agile Web Development<br>Christopher Prickett - 30053736<br>
	A website designed to move between multiple pages, with one page containing the questions and answers, with each able to be displayed. These questions will connect to 
	a database to retrieve all relevant information for the question.</p>
  </div>
</main>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>
